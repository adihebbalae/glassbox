// M5 daemon additions: standalone eval / screenshot / targeted wait / artifact listing. Each
// runs on a session already checked-not-paused by handleAction (so all four honor the PAUSED lane:
// while a breakpoint holds the queue, these refuse fast rather than hang). Kept out of actions.mjs
// so the M2 action delta path stays legible; wired in via handleAction's dispatch + one GET route.
import fs from 'node:fs';
import path from 'node:path';
import { CODES, gbErr } from '../protocol.mjs';

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

/** Compact, bounded preview of a non-returnable Runtime.RemoteObject (mirrors debug.mjs). */
function previewOf(v) {
  if (!v) return 'undefined';
  if ('value' in v) { try { return JSON.stringify(v.value).slice(0, 200); } catch { return String(v.value).slice(0, 200); } }
  if (v.description) return String(v.description).slice(0, 200);
  if (v.unserializableValue) return String(v.unserializableValue).slice(0, 200);
  return String(v.type).slice(0, 200);
}

// ---- eval -------------------------------------------------------------------

/**
 * Runtime.evaluate in the live page (NOT while paused — that lane is debug eval-on-frame). Returns
 * the value by-value when serializable, else a bounded preview, plus any console emitted DURING the
 * eval (mark/since) so `console.log`-style debugging surfaces without a second read call.
 */
export async function evalExpression(session, body) {
  const expression = String(body.expression ?? '');
  if (!expression) throw gbErr(CODES.BAD_REQUEST, 'eval needs an `expression`', { field: 'expression', correction_hint: 'pass a JS expression string' });
  const awaitPromise = !!body.awaitPromise;
  const t0 = Date.now();
  const mark = session.console.mark();
  const { cdp } = session;
  const common = { expression, awaitPromise, generatePreview: true, userGesture: true };
  let r;
  try {
    r = await cdp.send('Runtime.evaluate', { ...common, returnByValue: true });
  } catch {
    // returnByValue rejects on a non-serializable result (functions, DOM nodes, cycles) — retry by-ref.
    r = await cdp.send('Runtime.evaluate', { ...common, returnByValue: false });
  }
  const consoleDelta = session.console.since(mark, 20);
  const tookMs = Date.now() - t0;
  session.journal.log('command', { op: 'eval', threw: !!r.exceptionDetails, tookMs });
  if (r.exceptionDetails) {
    const ex = r.exceptionDetails.exception;
    return { ok: true, threw: true, error: (ex && ex.description) || r.exceptionDetails.text || 'eval threw', console: consoleDelta, tookMs };
  }
  const v = r.result || {};
  const out = { ok: true, type: v.type, console: consoleDelta, tookMs };
  if ('value' in v) out.value = v.value;
  else out.preview = previewOf(v);
  return out;
}

// ---- screenshot -------------------------------------------------------------

/** Union bounding box of a DOM quad [x1,y1,x2,y2,x3,y3,x4,y4]. */
function quadBox(q) {
  const xs = [q[0], q[2], q[4], q[6]], ys = [q[1], q[3], q[5], q[7]];
  const x = Math.min(...xs), y = Math.min(...ys);
  return { x, y, width: Math.max(...xs) - x, height: Math.max(...ys) - y };
}

// ---- forced paint for content-visibility:auto (defect W2) -------------------
// `content-visibility: auto` is a PERFORMANCE primitive: an off-screen subtree reserves its
// `contain-intrinsic-size` in layout but is never painted. `Page.captureScreenshot` with
// captureBeyondViewport does NOT force those subtrees to render, so a full-page capture stitches
// blank paper over every deferred section — an actively misleading artifact, because a reviewing
// agent reads a screenshot as primary evidence. So a full capture forces them to paint first and
// reports how many containers it forced.
//
// Two things matter in HOW. (1) Only `auto` is forced: `content-visibility: hidden` is a genuine
// hide primitive and must stay hidden, or the screenshot lies in the other direction. (2) Nothing
// is injected into the DOM — the rule goes into an INSPECTOR stylesheet (CSS.createStyleSheet, the
// DevTools mechanism), which is not a node, so the session's MutationObserver never fires, observe
// refs do not go stale, and mutation deltas stay honest.
const CV_COLLECT = `(() => {
  const path = (el) => {
    const parts = [];
    let n = el;
    while (n && n.nodeType === 1 && n !== document.documentElement) {
      let sel = n.tagName.toLowerCase();
      const p = n.parentElement;
      if (p) {
        const same = Array.prototype.filter.call(p.children, (c) => c.tagName === n.tagName);
        if (same.length > 1) sel += ':nth-of-type(' + (same.indexOf(n) + 1) + ')';
      }
      parts.unshift(sel);
      n = n.parentElement;
    }
    return parts.length ? ('html > ' + parts.join(' > ')) : 'html';
  };
  const out = [];
  for (const el of document.querySelectorAll('*')) {
    let cv = '';
    try { cv = getComputedStyle(el).contentVisibility; } catch (e) { continue; }
    if (cv === 'auto') { out.push(path(el)); if (out.length >= 200) break; }
  }
  return out;
})()`;

const paintTick = (page) => page
  .evaluate('new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(() => r(1), 30))))')
  .catch(() => {});

/**
 * Force every `content-visibility:auto` subtree to paint for the duration of a capture.
 * Returns {count, restore()}; restore() is always safe to call and puts the page back exactly.
 */
export async function forcePaint(session) {
  const { page, cdp } = session;
  const noop = { count: 0, restore: async () => {} };
  let paths = [];
  try { paths = await page.evaluate(CV_COLLECT); } catch { return noop; }
  if (!Array.isArray(paths) || !paths.length) return noop;
  let styleSheetId = null;
  try {
    await cdp.send('DOM.enable').catch(() => {});
    await cdp.send('CSS.enable').catch(() => {});
    const { frameTree } = await cdp.send('Page.getFrameTree');
    const frameId = frameTree?.frame?.id;
    if (!frameId) return noop;
    ({ styleSheetId } = await cdp.send('CSS.createStyleSheet', { frameId }));
    await cdp.send('CSS.setStyleSheetText', {
      styleSheetId,
      text: `${paths.join(',')} { content-visibility: visible !important; }`,
    });
  } catch {
    return noop; // CSS agent unavailable — capture exactly as before rather than fail the shot
  }
  await paintTick(page); // let layout + paint happen BEFORE the capture reads layout metrics
  return {
    count: paths.length,
    restore: async () => {
      try { await cdp.send('CSS.setStyleSheetText', { styleSheetId, text: '' }); } catch { /* sheet died with the document */ }
      await paintTick(page);
    },
  };
}

// Is a clipped capture suspiciously featureless? (defect W6 backstop.) An empty webp is almost all
// fixed overhead, so its size grows with the SQUARE ROOT of the area, while real content grows with
// the area — which is why a per-pixel floor cannot work: measured, a blank 1280×168 clip is 462 B
// (0.0022 B/px) but a large, legitimately sparse 1280×1432 block is 6486 B (0.0035 B/px), a LOWER
// rate than the blank. A sqrt floor separates every observed case: blank 462/970 fire, painted
// 6380/24626 and the sparse 6486 do not. It only applies to an element that reports itself visible
// AND has text or media — a plain solid-colour box is legitimately featureless.
export const blankFloorBytes = (w, h) => Math.round(300 + 2.2 * Math.sqrt(Math.max(1, w * h)));

/**
 * Read, in ONE call on the resolved element: whether it is visible, whether it has anything to
 * paint, and the page scroll offsets. The offsets matter because `DOM.getBoxModel` returns
 * VIEWPORT-relative coordinates (measured: y = -1500 at scrollY 1500, exactly like
 * getBoundingClientRect) while `Page.captureScreenshot` wants the clip in PAGE coordinates.
 */
const CLIP_PROBE_FN = `function(){
  var vis = true;
  try { vis = this.checkVisibility({ checkOpacity:true, checkVisibilityCSS:true, contentVisibilityAuto:true }); } catch(e) {}
  var text = '';
  try { text = (this.innerText || this.textContent || '').trim(); } catch(e) {}
  var media = false;
  try { media = !!this.querySelector('img,svg,canvas,video,picture,iframe'); } catch(e) {}
  return { visible: !!vis, hasContent: text.length > 0 || media, scrollX: window.scrollX || 0, scrollY: window.scrollY || 0 };
}`;

/**
 * Standalone screenshot via CDP captureScreenshot (webp q70) → an on-disk path under shots/, never
 * inline bytes (Claude Code's 10-20x ImageContent tax, research 04 §4.6). `selector` clips to the
 * element's border box; `fullPage` captures beyond the viewport; both force deferred
 * `content-visibility:auto` sections to paint first (pass `forcePaint:false` to opt out);
 * `theme` temporarily emulates the color-scheme then restores the session's own.
 * Returns {ok, path, bytes, w, h, forcedPaint?, warning?}.
 */
export async function screenshotAction(session, body) {
  const { cdp, page } = session;
  await cdp.send('Page.enable').catch(() => {});
  const theme = body.theme === 'light' || body.theme === 'dark' ? body.theme : null;
  if (theme) await page.emulateMedia({ colorScheme: theme }).catch(() => {});
  // W6: the old rule was "only the full-page path needs a forced paint — a viewport or element
  // capture paints what is actually on screen". False on both halves. An element inside an
  // unpainted `content-visibility:auto` section clips to blank paper exactly like the full-page
  // case did, so the selector path force-paints too; and the clip's coordinate basis was wrong
  // whenever the page was scrolled (see below), which is what actually produced the filed blanks.
  const wantForce = (!!body.fullPage || !!body.selector) && body.forcePaint !== false;
  const forced = wantForce ? await forcePaint(session) : { count: 0, restore: async () => {} };
  try {
    const params = { format: 'webp', quality: 70 };
    let w, h, probe = null;
    if (body.selector) {
      const { result } = await cdp.send('Runtime.evaluate', { expression: `document.querySelector(${JSON.stringify(body.selector)})`, returnByValue: false });
      if (!result || !result.objectId) throw gbErr(CODES.NO_TARGET, `selector '${body.selector}' matched nothing to screenshot`, { field: 'selector', correction_hint: 'check the selector' });
      let box;
      try {
        box = (await cdp.send('DOM.getBoxModel', { objectId: result.objectId })).model;
        const pr = await cdp.send('Runtime.callFunctionOn', { objectId: result.objectId, functionDeclaration: CLIP_PROBE_FN, returnByValue: true }).catch(() => null);
        probe = pr?.result?.value || null;
      } finally { cdp.send('Runtime.releaseObject', { objectId: result.objectId }).catch(() => {}); }
      const b = quadBox(box.border);
      if (b.width < 1 || b.height < 1) throw gbErr(CODES.NO_TARGET, `selector '${body.selector}' has a zero-size box`, { field: 'selector' });
      // THE W6 BUG, measured: `DOM.getBoxModel` hands back VIEWPORT-relative coordinates while
      // `Page.captureScreenshot` wants the clip in PAGE coordinates. They agree only at scroll 0,
      // so every capture taken after ANY scroll silently framed the wrong region — and since
      // clicking a control scrolls it into view, one click was enough to poison every element
      // screenshot for the rest of the session (the filed repro blamed the <details> it clicked;
      // the details was innocent, the scroll it caused was not). Convert the basis explicitly, and
      // capture beyond the viewport so an element below the fold is captured where it really is.
      params.clip = {
        x: b.x + (probe?.scrollX || 0),
        y: b.y + (probe?.scrollY || 0),
        width: b.width, height: b.height, scale: 1,
      };
      params.captureBeyondViewport = true;
      params.fromSurface = true;
      w = Math.round(b.width); h = Math.round(b.height);
    } else if (body.fullPage) {
      params.captureBeyondViewport = true;
      const m = await cdp.send('Page.getLayoutMetrics').catch(() => null);
      const cs = m && (m.cssContentSize || m.contentSize);
      w = cs ? Math.round(cs.width) : null; h = cs ? Math.round(cs.height) : null;
    } else {
      const m = await cdp.send('Page.getLayoutMetrics').catch(() => null);
      const vp = m && (m.cssLayoutViewport || m.layoutViewport);
      w = vp ? Math.round(vp.clientWidth) : null; h = vp ? Math.round(vp.clientHeight) : null;
    }
    const { data } = await cdp.send('Page.captureScreenshot', params);
    const buf = Buffer.from(data, 'base64');
    const p = session.journal.alloc('shots', `shot-${Date.now()}.webp`);
    fs.writeFileSync(p, buf);
    // Backstop (W6, same principle as W2): never hand back a blank primary artifact silently. If a
    // visible element with something to paint clipped to a near-featureless image, say so in the
    // result — the caller can re-shoot the viewport, which uses a different capture path.
    let warning;
    if (body.selector && probe?.visible && probe?.hasContent && w > 0 && h > 0 && buf.length < blankFloorBytes(w, h)) {
      warning = `clip may be blank: ${buf.length} bytes for a ${w}×${h} region, below the ${Math.round(blankFloorBytes(w, h))}-byte floor, on an element that reports itself visible with content. It was already force-painted before capture; take a viewport screenshot (no selector) to cross-check.`;
    }
    session.journal.log('command', { op: 'screenshot', path: p, bytes: buf.length, ...(forced.count ? { forcedPaint: forced.count } : {}), ...(warning ? { warning } : {}) });
    return { ok: true, path: p, bytes: buf.length, w, h, ...(wantForce ? { forcedPaint: forced.count } : {}), ...(warning ? { warning } : {}) };
  } finally {
    await forced.restore();
    if (theme) await page.emulateMedia({ colorScheme: session.colorScheme || null }).catch(() => {});
  }
}

// ---- wait -------------------------------------------------------------------

/**
 * URL-pattern predicate, evaluated in the page (defect D7). Two dialects, chosen by the pattern:
 *   - starts with `/` → a PATHNAME match: exact, or a prefix that ends on a path SEGMENT boundary
 *     (`/dashboard` matches /dashboard and /dashboard/settings, never /dashboardx). This is the
 *     form SKILL.md documents (`for:{url:"/dashboard"}`) and the natural one to write; the old
 *     substring-of-href rule made `/plan` silently match `/planner`.
 *   - anything else → substring of location.href (unchanged: 'planner', 'http://host/planner').
 * A `*` anywhere turns the pattern into a glob against the pathname (leading `/`) or the href.
 */
const urlMatches = (u) => {
  const glob = (pat, s) => new RegExp('^' + pat.split('*').map((p) => p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('.*') + '$').test(s);
  if (u.charAt(0) === '/') {
    const p = location.pathname;
    if (u.indexOf('*') >= 0) return glob(u, p);
    if (p === u) return true;
    return p.indexOf(u.charAt(u.length - 1) === '/' ? u : u + '/') === 0;
  }
  if (u.indexOf('*') >= 0) return glob(u, location.href);
  return location.href.indexOf(u) >= 0;
};

/**
 * Targeted wait, distinct from settle: block until ONE named condition holds, or the budget lapses.
 * `for`: {selector} (visible) | {text} (substring in body) | {url} (pathname or href pattern) |
 * {hydration:true} (no astro-island[ssr]) | {timeout:ms} (a plain sleep). NEVER throws on timeout —
 * returns {ok, matched:false} so the agent can branch instead of catching. A missing/blank `for`
 * (nothing to wait on) is the one BAD_REQUEST.
 *
 * A plain sleep has nothing to match and nothing to time out (defect D10): the requested duration
 * IS the budget, so it is never clipped by the action timeout (which used to make `sleep 15000`
 * return "MATCHED in 10000ms" — a lie) and it always reports matched:true.
 */
export async function waitFor(session, body) {
  const spec = body.for || {};
  const t0 = Date.now();
  const timeoutMs = body.timeoutMs > 0 ? Math.min(Number(body.timeoutMs), 120000) : 10000;
  const { page } = session;
  try {
    if (spec.selector) {
      await page.waitForSelector(spec.selector, { state: 'visible', timeout: timeoutMs });
    } else if (spec.text != null && spec.text !== '') {
      await page.waitForFunction((t) => !!document.body && document.body.innerText.includes(t), spec.text, { timeout: timeoutMs, polling: 100 });
    } else if (spec.url != null && spec.url !== '') {
      await page.waitForFunction(urlMatches, String(spec.url), { timeout: timeoutMs, polling: 100 });
    } else if (spec.hydration) {
      await page.waitForFunction(() => !document.querySelector('astro-island[ssr]'), undefined, { timeout: timeoutMs, polling: 100 });
    } else if (spec.timeout != null) {
      const ms = Math.max(0, Math.min(Number(spec.timeout) || 0, 600000)); // own budget; capped at 10min
      await delay(ms);
      session.journal.log('command', { op: 'wait', sleep: ms, matched: true });
      return { ok: true, matched: true, slept: ms, tookMs: Date.now() - t0 };
    } else {
      throw gbErr(CODES.BAD_REQUEST, 'wait needs `for` with one of: selector|text|url|hydration|timeout', {
        field: 'for', valid_values: ['selector', 'text', 'url', 'hydration', 'timeout'],
        correction_hint: 'e.g. for:{selector:"#done"} or for:{text:"Loaded"}',
      });
    }
    const tookMs = Date.now() - t0;
    session.journal.log('command', { op: 'wait', matched: true, tookMs });
    return { ok: true, matched: true, tookMs };
  } catch (e) {
    if (e && e.gb) throw e; // a real BAD_REQUEST (bad `for`) — surface it
    const tookMs = Date.now() - t0;
    session.journal.log('command', { op: 'wait', matched: false, tookMs });
    return { ok: true, matched: false, tookMs }; // timeout / detach — never throw
  }
}

// ---- viewport ---------------------------------------------------------------

/**
 * Resize an EXISTING session (defect D11). Viewport used to be frozen at `session open`, so a
 * mobile check meant opening a second session and re-seeding all of its state; a theme×viewport
 * matrix cost N sessions. Runs on the serial queue like any other action, is journaled, and
 * reports the viewport the page actually ended up with.
 */
export async function setViewport(session, body) {
  const src = body.viewport && typeof body.viewport === 'object' ? body.viewport : body;
  const width = Math.round(Number(src.width));
  const height = Math.round(Number(src.height));
  if (!(width >= 50 && width <= 10000) || !(height >= 50 && height <= 10000)) {
    throw gbErr(CODES.BAD_REQUEST, 'viewport needs {width,height} in CSS px (50-10000)', {
      field: 'viewport', correction_hint: 'e.g. {width:390,height:844} — CLI: session resize <name> 390x844',
    });
  }
  await session.page.setViewportSize({ width, height });
  const inner = await session.page.evaluate(() => ({ w: window.innerWidth, h: window.innerHeight })).catch(() => null);
  session.journal.log('command', { op: 'viewport', width, height });
  return { ok: true, name: session.name, viewport: { width, height }, inner, url: session.page.url() };
}

// ---- artifacts --------------------------------------------------------------

/** List a session's on-disk artifacts grouped by kind (shots/reports/net/journal), newest first. */
export function listArtifacts(session) {
  const j = session.journal;
  const groups = { shots: j.shots, reports: j.reports, net: j.net, journal: j.dir };
  const artifacts = {};
  for (const [kind, d] of Object.entries(groups)) {
    const files = [];
    let names = [];
    try { names = fs.readdirSync(d); } catch { names = []; }
    for (const name of names) {
      const fp = path.join(d, name);
      let st;
      try { st = fs.statSync(fp); } catch { continue; }
      if (st.isDirectory()) continue; // 'journal' kind: dir listing skips the shots/reports/net subdirs
      files.push({ rel: path.relative(j.dir, fp), path: fp, bytes: st.size, mtime: Math.round(st.mtimeMs) });
    }
    artifacts[kind] = files.sort((a, b) => b.mtime - a.mtime);
  }
  return { ok: true, dir: j.dir, artifacts };
}
